document.getElementById("nov41").onclick = function () {
  localStorage.setItem("baza", 4);
};
document.getElementById("nov42").onclick = function () {
  localStorage.setItem("baza", 4);
};
document.getElementById("nov43").onclick = function () {
  localStorage.setItem("baza", 4);
};
document.getElementById("nov44").onclick = function () {
  localStorage.setItem("baza", 4);
};
document.getElementById("nov45").onclick = function () {
  localStorage.setItem("baza", 4);
};
document.getElementById("nov46").onclick = function () {
  localStorage.setItem("baza", 4);
};
document.getElementById("nov47").onclick = function () {
  localStorage.setItem("baza", 4);
};
document.getElementById("nov48").onclick = function () {
  localStorage.setItem("baza", 4);
};
document.getElementById("nov49").onclick = function () {
  localStorage.setItem("baza", 4);
};
document.getElementById("nov410").onclick = function () {
  localStorage.setItem("baza", 4);
};
document.getElementById("nov411").onclick = function () {
  localStorage.setItem("baza", 4);
};
document.getElementById("nov412").onclick = function () {
  localStorage.setItem("baza", 4);
};
