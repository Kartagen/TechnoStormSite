document.getElementById("nov11").onclick = function () {
  localStorage.setItem("baza", 1);
};
document.getElementById("nov12").onclick = function () {
  localStorage.setItem("baza", 1);
};
document.getElementById("nov13").onclick = function () {
  localStorage.setItem("baza", 1);
};
document.getElementById("nov14").onclick = function () {
  localStorage.setItem("baza", 1);
};
document.getElementById("nov15").onclick = function () {
  localStorage.setItem("baza", 1);
};
document.getElementById("nov16").onclick = function () {
  localStorage.setItem("baza", 1);
};
document.getElementById("nov17").onclick = function () {
  localStorage.setItem("baza", 1);
};
document.getElementById("nov18").onclick = function () {
  localStorage.setItem("baza", 1);
};
document.getElementById("nov19").onclick = function () {
  localStorage.setItem("baza", 1);
};
document.getElementById("nov110").onclick = function () {
  localStorage.setItem("baza", 1);
};
document.getElementById("nov111").onclick = function () {
  localStorage.setItem("baza", 1);
};
document.getElementById("nov112").onclick = function () {
  localStorage.setItem("baza", 1);
};
