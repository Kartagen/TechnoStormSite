document.getElementById("nov21").onclick = function () {
  localStorage.setItem("baza", 3);
};
document.getElementById("nov22").onclick = function () {
  localStorage.setItem("baza", 2);
};
document.getElementById("nov23").onclick = function () {
  localStorage.setItem("baza", 3);
};
document.getElementById("nov24").onclick = function () {
  localStorage.setItem("baza", 2);
};
document.getElementById("nov25").onclick = function () {
  localStorage.setItem("baza", 3);
};
document.getElementById("nov26").onclick = function () {
  localStorage.setItem("baza", 2);
};
document.getElementById("nov27").onclick = function () {
  localStorage.setItem("baza", 3);
};
document.getElementById("nov28").onclick = function () {
  localStorage.setItem("baza", 2);
};
document.getElementById("nov29").onclick = function () {
  localStorage.setItem("baza", 3);
};
document.getElementById("nov210").onclick = function () {
  localStorage.setItem("baza", 2);
};
document.getElementById("nov211").onclick = function () {
  localStorage.setItem("baza", 3);
};
document.getElementById("nov212").onclick = function () {
  localStorage.setItem("baza", 2);
};
